# 單字四選一（GitHub Pages 版）

一個可**直接丟到 GitHub Pages** 的英中單字練習小遊戲。支援：

- 題庫標籤：`學測`、`多益`、`托福`、`7000單`
- 題型：**英→中**（給英文單字，選中文解釋）／**中→英**（給中文解釋，選英文單字）／**混合**
- 每題四選一
- 朗讀（瀏覽器語音合成 API）
- 錯題本、連對計數（本機 LocalStorage）
- **CSV 匯入**自訂單字：欄位 `en, zh, pos, tags`（`tags` 多個以逗號分隔）
- 匯出/重置進度

> 預設資料只放示範數十筆，請自行擴充（CSV 最方便）。

---

## 部署到 GitHub Pages

1. 建一個公開 repo（或私人也可以，但 Pages 要開啟）。
2. 把整個資料夾內容上傳到 repo 根目錄（確保 `index.html` 在根目錄）。
3. 進入 **Settings → Pages**：
   - Source 選擇 **Deploy from a branch**
   - Branch 選擇 **main / (root)**，存檔
4. 等待幾十秒，頁面 URL 就會出現，打開即可遊玩。

> 若你的 repo 有子資料夾或自訂 base path，請確保 `fetch('data/vocab.json')` 能取到檔案（可改為絕對路徑或加入 `base` 設定）。

---

## 題庫資料格式

`data/vocab.json`：

```json
[
  {"id":"abandon::放棄；遺棄","en":"abandon","zh":"放棄；遺棄","pos":"v.","tags":["7000單","學測"]}
]
```

- `id`：任意唯一字串（預設用 `en::zh`）。
- `en`：英文單字或片語。
- `zh`：中文解釋。
- `pos`：詞性，可留空。
- `tags`：標籤陣列（至少一個）。

### 匯入 CSV

- 檔頭必須至少有 `en, zh`；可選 `pos, tags`。
- `tags` 可用逗號分隔多個，例如：`學測,7000單`。
- 匯入後會與現有題庫**去重**（以 `id` 為準）。

---

## 小技巧

- 「忽略已全對」：對同一字連續答對 2 次，就暫時不再出題，幫你把時間集中在不熟的字。
- 數字鍵 `1~4` 直接作答；`Enter` 下一題。
- 朗讀只在英→中或題目是英文時有用。

---

## 自訂／擴充

- 想改預設標籤：編輯 `index.html` 中的 `TAGS`（在 `script.js` 開頭也有同名常數）。
- 想固定使用自己的題庫：
  1. 把你的單字做成 `data/mywords.json`；
  2. 在 `script.js` 的 `loadData()` 改為同時 `fetch` 你的檔，或取代 `vocab.json`。
- 想上傳音檔：可自行在 UI 增加 `<audio>` 或使用第三方 TTS，但 GitHub Pages 需注意跨域/金鑰。

---

## 授權

MIT License — 你可以任意修改與發佈。祝考試順利！
