// Vocabulary Game Script
// Data format: see data/vocab.json
const TAGS = ["學測","多益","托福","7000單"];
const STORAGE_KEYS = {
  settings: "vg_settings_v1",
  mastery: "vg_mastery_v1",
  wrong: "vg_wrong_v1"
};

const el = s => document.querySelector(s);
const els = s => Array.from(document.querySelectorAll(s));

let DATA = [];            // full dataset
let POOL = [];            // filtered
let mode = "EN_ZH";       // EN_ZH | ZH_EN | MIX
let qCount = 20;
let skipMastered = false;
let index = 0;
let correct = 0;
let streak = 0;
let order = [];
let current = null;
let options = [];
let mastered = {};        // {id: {right: n, wrong: n}}
let wrongBook = [];       // array of ids

async function loadData(){
  // Load bundled
  const res = await fetch('data/vocab.json?_=' + Date.now());
  const base = await res.json();
  DATA = base;
  // Merge mastery from storage
  const m = JSON.parse(localStorage.getItem(STORAGE_KEYS.mastery) || "{}");
  mastered = m;
  const w = JSON.parse(localStorage.getItem(STORAGE_KEYS.wrong) || "[]");
  wrongBook = w;
  // Restore settings
  const s = JSON.parse(localStorage.getItem(STORAGE_KEYS.settings) || "{}");
  if (s.mode) mode = s.mode;
  if (s.qCount) qCount = s.qCount;
  if (s.selectedTags) selectedTags = new Set(s.selectedTags);
  if (s.skipMastered != null) skipMastered = s.skipMastered;
  renderControls();
  refreshPool();
  renderReview();
  updateStats();
}

let selectedTags = new Set(TAGS); // default all on

function renderControls(){
  const chips = el('#tagChips');
  chips.innerHTML = "";
  TAGS.forEach(tag => {
    const node = document.createElement('label');
    node.className = 'chip' + (selectedTags.has(tag) ? ' active' : '');
    node.innerHTML = `<input type="checkbox" ${selectedTags.has(tag)?'checked':''} data-tag="${tag}">${tag}`;
    chips.appendChild(node);
  });
  chips.addEventListener('click', e => {
    const input = e.target.closest('input[type="checkbox"]');
    if(!input) return;
    const tag = input.dataset.tag;
    if (selectedTags.has(tag)) selectedTags.delete(tag); else selectedTags.add(tag);
    input.parentElement.classList.toggle('active');
    refreshPool();
  }, {once:false});

  // modes
  const setMode = v => {
    mode = v;
    saveSettings();
  }
  el('#modeEnZh').onclick = _=>{ setMode('EN_ZH'); el('#modeEnZh').classList.add('active'); el('#modeZhEn').classList.remove('active'); el('#modeMix').classList.remove('active')};
  el('#modeZhEn').onclick = _=>{ setMode('ZH_EN'); el('#modeZhEn').classList.add('active'); el('#modeEnZh').classList.remove('active'); el('#modeMix').classList.remove('active')};
  el('#modeMix').onclick  = _=>{ setMode('MIX');   el('#modeMix').classList.add('active');  el('#modeEnZh').classList.remove('active'); el('#modeZhEn').classList.remove('active')};

  el('#questionCount').value = qCount;
  el('#questionCount').addEventListener('change', e => {
    qCount = Math.max(5, Math.min(200, Number(e.target.value)||20));
    saveSettings();
  });

  el('#skipMastered').checked = skipMastered;
  el('#skipMastered').addEventListener('change', e=>{
    skipMastered = e.target.checked;
    saveSettings();
    refreshPool();
  });

  // actions
  el('#startBtn').onclick = start;
  el('#nextBtn').onclick = next;
  el('#showAnswerBtn').onclick = showAnswer;
  document.addEventListener('keydown', e => {
    if (e.key === 'Enter') next();
    if (['1','2','3','4'].includes(e.key)){
      const i = Number(e.key) - 1;
      const btns = els('.option');
      if(btns[i]) btns[i].click();
    }
  });
  el('#speakBtn').onclick = speak;

  // review
  el('#reviewBtn').onclick = _ => {
    el('#reviewCard').classList.toggle('hidden');
  };
  el('#clearWrong').onclick = _ => {
    wrongBook = [];
    persistWrong();
    renderReview();
  };

  // import csv
  el('#csvInput').addEventListener('change', handleCSV, false);
  el('#exportBtn').onclick = exportProgress;
  el('#resetBtn').onclick = resetProgress;
}

function saveSettings(){
  localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify({
    mode, qCount, selectedTags: Array.from(selectedTags), skipMastered
  }));
}

function resetProgress(){
  if (!confirm('確定要重置所有進度與錯題本？')) return;
  mastered = {};
  wrongBook = [];
  persistMastery();
  persistWrong();
  updateStats();
  renderReview();
  alert('已重置。');
}

function refreshPool(){
  POOL = DATA.filter(it => it.tags.some(t => selectedTags.has(t)));
  if (skipMastered){
    POOL = POOL.filter(x => (mastered[x.id]?.right||0) < 2); // 連對2次視為暫時掌握
  }
}

function start(){
  refreshPool();
  if (POOL.length < 4) {
    alert('選取的清單不足以出題（至少 4 筆）。請增加清單或匯入單字。');
    return;
  }
  index = 0; correct = 0; streak = 0;
  order = shuffle(POOL).slice(0, Math.min(qCount, POOL.length));
  el('#qTotal').textContent = order.length;
  next();
}

function next(){
  if (!order.length || index >= order.length){
    el('#question').textContent = '完成！可以重新開始或更換設定～';
    el('#options').innerHTML = '';
    el('#nextBtn').disabled = true;
    return;
  }
  current = order[index];
  index++;
  el('#qIndex').textContent = index;
  el('#nextBtn').disabled = true;

  const realMode = (mode === 'MIX') ? (Math.random() < .5 ? 'EN_ZH' : 'ZH_EN') : mode;
  el('#posHint').textContent = current.pos ? `詞性：${current.pos}` : '';

  if (realMode === 'EN_ZH'){
    el('#question').innerHTML = escapeHTML(current.en) + (current.pos ? `<span class="pos">${current.pos}</span>` : '');
    options = buildOptions(current, 'zh').map(o => ({label:o.zh, id:o.id, correct:o.id===current.id}));
  }else{
    el('#question').innerHTML = escapeHTML(current.zh);
    options = buildOptions(current, 'en').map(o => ({label:o.en, id:o.id, correct:o.id===current.id}));
  }
  renderOptions(options);
  updateStats();
}

function buildOptions(target, field){
  // pick 3 others with same pos first; fallback random
  const samePOS = POOL.filter(x => x.id !== target.id && x.pos === target.pos);
  const others = samePOS.length >= 3 ? shuffle(samePOS).slice(0,3)
                : shuffle(POOL.filter(x => x.id !== target.id)).slice(0,3);
  const arr = shuffle([target, ...others]);
  // remove duplicates by field text
  const seen = new Set();
  const uniq = [];
  for (const o of arr){
    const key = o[field].trim().toLowerCase();
    if (!seen.has(key)){ seen.add(key); uniq.push(o); }
  }
  while (uniq.length < 4){
    const extra = POOL[Math.floor(Math.random()*POOL.length)];
    if (!uniq.find(x => x.id === extra.id)) uniq.push(extra);
  }
  return uniq.slice(0,4);
}

function renderOptions(opts){
  const box = el('#options');
  box.innerHTML = "";
  opts.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'option';
    btn.innerHTML = `<span class="tiny">(${i+1})</span> ${escapeHTML(opt.label)}`;
    btn.onclick = () => select(opt);
    box.appendChild(btn);
  });
}

function select(opt){
  const btns = els('.option');
  btns.forEach(b => b.disabled = true);
  const correctBtn = btns[options.findIndex(o => o.correct)];
  const clickedBtn = btns[options.indexOf(opt)];

  if (opt.correct){
    clickedBtn.classList.add('good');
    correct++; streak++;
    incMastery(current.id, true);
  }else{
    clickedBtn.classList.add('bad');
    correctBtn.classList.add('good');
    streak = 0;
    incMastery(current.id, false);
    addWrong(current.id);
  }
  updateStats();
  el('#nextBtn').disabled = false;
}

function showAnswer(){
  const btns = els('.option');
  if (!btns.length) return;
  const correctBtn = btns[options.findIndex(o => o.correct)];
  correctBtn.classList.add('good');
}

function updateStats(){
  const total = Math.max(1, index-0); // avoid 0
  const acc = Math.round((correct / Math.max(1, index-1)) * 100) || 0;
  el('#correct').textContent = correct;
  el('#accuracy').textContent = acc + '%';
  el('#streak').textContent = streak;
}

function speak(){
  if (!current) return;
  const utter = new SpeechSynthesisUtterance(current.en);
  utter.lang = 'en-US';
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utter);
}

function incMastery(id, right){
  mastered[id] = mastered[id] || {right:0, wrong:0};
  if (right) mastered[id].right++; else mastered[id].wrong++;
  persistMastery();
}
function persistMastery(){ localStorage.setItem(STORAGE_KEYS.mastery, JSON.stringify(mastered)); }

function addWrong(id){
  if (!wrongBook.includes(id)) wrongBook.unshift(id);
  wrongBook = wrongBook.slice(0, 500);
  persistWrong();
  renderReview();
}
function persistWrong(){ localStorage.setItem(STORAGE_KEYS.wrong, JSON.stringify(wrongBook)); }

function renderReview(){
  const area = el('#reviewList');
  area.innerHTML = "";
  const list = wrongBook.map(id => DATA.find(x => x.id === id)).filter(Boolean);
  if (!list.length){
    area.innerHTML = '<div class="tiny">尚無錯題。</div>';
    return;
  }
  list.forEach(item => {
    const btn = document.createElement('button');
    btn.className = 'option';
    btn.innerHTML = `<b>${escapeHTML(item.en)}</b> <span class="tiny">${item.pos||""}</span><br>${escapeHTML(item.zh)}<br><span class="tiny">${item.tags.join(", ")}</span>`;
    btn.onclick = () => {
      // quick drill on this word
      order = [item];
      index = 0; correct = 0; streak = 0;
      el('#qTotal').textContent = 1;
      next();
      el('#reviewCard').classList.add('hidden');
    };
    area.appendChild(btn);
  });
}

function exportProgress(){
  const payload = {
    settings: JSON.parse(localStorage.getItem(STORAGE_KEYS.settings) || "{}"),
    mastery: JSON.parse(localStorage.getItem(STORAGE_KEYS.mastery) || "{}"),
    wrong: JSON.parse(localStorage.getItem(STORAGE_KEYS.wrong) || "[]"),
    exported_at: new Date().toISOString()
  };
  const blob = new Blob([JSON.stringify(payload,null,2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'vocab-progress.json';
  a.click();
  URL.revokeObjectURL(url);
}

async function handleCSV(ev){
  const file = ev.target.files[0];
  if (!file) return;
  const text = await file.text();
  const rows = csvToRows(text);
  const header = rows.shift().map(s=>s.trim().toLowerCase());
  const idx = {
    en: header.indexOf('en'),
    zh: header.indexOf('zh'),
    pos: header.indexOf('pos'),
    tags: header.indexOf('tags')
  };
  if (idx.en<0 || idx.zh<0){
    alert('CSV 必須至少包含 en, zh 欄位。');
    return;
  }
  const imported = [];
  for (const r of rows){
    const en = (r[idx.en]||'').trim();
    const zh = (r[idx.zh]||'').trim();
    if (!en || !zh) continue;
    const pos = idx.pos>=0 ? (r[idx.pos]||'').trim() : '';
    const tags = idx.tags>=0 ? (r[idx.tags]||'').split(',').map(s=>s.trim()).filter(Boolean) : [];
    if (!tags.length) tags.push('自訂');
    imported.push({
      id: `${en}::${zh}`,
      en, zh, pos, tags
    });
  }
  DATA = dedupe([...DATA, ...imported]);
  refreshPool();
  alert(`已匯入 ${imported.length} 筆單字`);
}

function csvToRows(text){
  // Simple CSV parser (comma, quote)
  const rows = [];
  let row = [], cell = '', inQ = false;
  for (let i=0;i<text.length;i++){
    const ch = text[i];
    if (inQ){
      if (ch === '"'){
        if (text[i+1] === '"'){ cell += '"'; i++; } else { inQ = false; }
      }else cell += ch;
    }else{
      if (ch === '"') inQ = true;
      else if (ch === ','){ row.push(cell); cell=''; }
      else if (ch === '\n'){ row.push(cell); rows.push(row); row=[]; cell=''; }
      else if (ch === '\r'){ /* ignore */ }
      else cell += ch;
    }
  }
  if (cell.length || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

function dedupe(arr){
  const map = new Map();
  for (const it of arr){ map.set(it.id, it); }
  return Array.from(map.values());
}

function shuffle(a){
  const arr = a.slice();
  for (let i=arr.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    [arr[i],arr[j]]=[arr[j],arr[i]];
  }
  return arr;
}

function escapeHTML(s){
  return (s||'').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

window.addEventListener('DOMContentLoaded', loadData);
